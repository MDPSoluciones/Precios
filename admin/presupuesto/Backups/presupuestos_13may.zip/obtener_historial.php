<?php
header("Content-Type: application/json");

$archivo = "historial.json";

if (!file_exists($archivo)) {
    echo json_encode([]);
    exit;
}

echo file_get_contents($archivo);
?>