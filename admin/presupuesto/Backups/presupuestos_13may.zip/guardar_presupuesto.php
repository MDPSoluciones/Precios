<?php
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit;
}

$archivo = "historial.json";
$contadorFile = "contador.txt";

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["status" => "error"]);
    exit;
}

// crear archivos si no existen
if (!file_exists($archivo)) {
    file_put_contents($archivo, json_encode([]));
}

if (!file_exists($contadorFile)) {
    file_put_contents($contadorFile, "1");
}

// leer contador
$numero = (int)file_get_contents($contadorFile);

// generar código tipo PRES-00001
$codigo = "PRES-" . str_pad($numero, 5, "0", STR_PAD_LEFT);

// incrementar contador
file_put_contents($contadorFile, $numero + 1);

// agregar código al presupuesto
$data["presupuesto"]["codigo"] = $codigo;

// guardar historial
$historial = json_decode(file_get_contents($archivo), true);
$historial[] = $data;

file_put_contents($archivo, json_encode($historial, JSON_PRETTY_PRINT));

echo json_encode([
    "status" => "ok",
    "codigo" => $codigo
]);
?>