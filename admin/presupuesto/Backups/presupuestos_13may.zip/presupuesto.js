// ─── Estado global ────────────────────────────────────────────────────────────
let productos = [];
let historial = [];
let clientesGuardados = [];
let ultimoPresupuesto = null;
let indiceProdEditando = null; // null = modo agregar | número = modo editar

// ─── Inicialización ───────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    cargarHistorial();
    cargarClientes();
    iniciarAutocompletado();

    // Fecha de hoy por defecto
    const hoy = new Date().toISOString().split("T")[0];
    document.getElementById("fecha").value = hoy;
});

// ─── Empresa ──────────────────────────────────────────────────────────────────
function cambiarEmpresa() {
    const toggle = document.getElementById("empresa_toggle");
    if (toggle.checked) {
        document.getElementById("header_nombre").innerText = "MDP SOLUCIONES";
        document.getElementById("empresa_nombre").value = "MDP SOLUCIONES";
        document.getElementById("empresa_cuit").value = "20-35023798-5";
        document.getElementById("empresa_direccion").value = "Sarmiento 24";
        document.getElementById("empresa_mail").value = "";
        document.getElementById("empresa_tel").value = "";
    } else {
        document.getElementById("header_nombre").innerText = "AXENTIA";
        document.getElementById("empresa_nombre").value = "AXENTIA S.R.L.";
        document.getElementById("empresa_cuit").value = "30-71902891-4";
        document.getElementById("empresa_direccion").value = "Marinero Sosa 854";
        document.getElementById("empresa_mail").value = "adm.axentia@gmail.com";
        document.getElementById("empresa_tel").value = "+54 9 3364 24-9663";
    }
}

// ─── Clientes ─────────────────────────────────────────────────────────────────
function cargarClientes() {
    fetch("obtener_clientes.php")
        .then(res => res.json())
        .then(data => {
            clientesGuardados = data;
        })
        .catch(err => console.error("Error cargando clientes:", err));
}

function guardarClienteServidor(cliente) {
    fetch("guardar_cliente.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cliente)
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === "ok") cargarClientes();
        })
        .catch(err => console.error("Error guardando cliente:", err));
}

function iniciarAutocompletado() {
    const inputCliente = document.getElementById("cliente_nombre");
    const boxSugerencias = document.getElementById("sugerencias_clientes");

    inputCliente.addEventListener("input", function () {
        const texto = this.value.toLowerCase();
        if (texto.length < 2) {
            boxSugerencias.style.display = "none";
            return;
        }
        const resultados = clientesGuardados.filter(c =>
            c.nombre && c.nombre.toLowerCase().includes(texto)
        );
        mostrarSugerencias(resultados);
    });

    document.addEventListener("click", function (e) {
        if (!e.target.closest("#cliente_nombre")) {
            boxSugerencias.style.display = "none";
        }
    });
}

function mostrarSugerencias(lista) {
    const box = document.getElementById("sugerencias_clientes");
    box.innerHTML = "";
    if (lista.length === 0) {
        box.style.display = "none";
        return;
    }
    lista.forEach(c => {
        const div = document.createElement("div");
        div.innerHTML = `<strong>${c.nombre}</strong><br><small>${c.cuit || ""}</small>`;
        div.style.padding = "8px";
        div.style.cursor = "pointer";
        div.onmouseover = () => div.style.background = "#eee";
        div.onmouseout = () => div.style.background = "#fff";
        div.onclick = () => seleccionarCliente(c);
        box.appendChild(div);
    });
    box.style.display = "block";
}

function seleccionarCliente(c) {
    document.getElementById("cliente_nombre").value = c.nombre || "";
    document.getElementById("cliente_cuit").value = c.cuit || "";
    document.getElementById("cliente_direccion").value = c.direccion || "";
    document.getElementById("cliente_mail").value = c.mail || "";
    document.getElementById("sugerencias_clientes").style.display = "none";
}

// ─── Productos ────────────────────────────────────────────────────────────────
function agregarProducto() {
    const desc = document.getElementById("producto_desc").value.trim();
    const cant = parseInt(document.getElementById("producto_cant").value);
    const precio = parseFloat(document.getElementById("producto_precio").value);
    const ivaPorc = parseFloat(document.getElementById("producto_iva").value) || 0;
    const moneda = document.getElementById("moneda").value;

    if (!desc || isNaN(cant) || isNaN(precio)) {
        alert("Completá descripción, cantidad y precio.");
        return;
    }

    const subTotalBase = cant * precio;
    const totalIVA = subTotalBase * ivaPorc / 100;
    const item = { desc, cant, precio, subTotalBase, ivaPorc, totalIVA };

    if (indiceProdEditando !== null) {
        // ── Modo edición: reemplazar el item existente ──
        productos[indiceProdEditando] = item;
        indiceProdEditando = null;
        document.getElementById("aviso_edicion").style.display = "none";
        document.getElementById("form_productos").classList.remove("modo-edicion");
        document.getElementById("btn_agregar_prod").textContent = "Agregar producto";
        document.getElementById("btn_cancelar_edicion").style.display = "none";
    } else {
        // ── Modo normal: agregar al final ──
        productos.push(item);
    }

    limpiarFormProducto();
    actualizarTabla(moneda);
}

function editarProducto(i) {
    const p = productos[i];
    document.getElementById("producto_desc").value = p.desc;
    document.getElementById("producto_cant").value = p.cant;
    document.getElementById("producto_precio").value = p.precio;
    document.getElementById("producto_iva").value = p.ivaPorc;

    indiceProdEditando = i;
    document.getElementById("aviso_edicion").style.display = "inline-block";
    document.getElementById("aviso_edicion").textContent = `✏️ Editando ítem ${i + 1}: "${p.desc}"`;
    document.getElementById("form_productos").classList.add("modo-edicion");
    document.getElementById("btn_agregar_prod").textContent = "Guardar cambios";
    document.getElementById("btn_cancelar_edicion").style.display = "inline-block";

    document.getElementById("form_productos").scrollIntoView({ behavior: "smooth", block: "center" });
}

function cancelarEdicion() {
    indiceProdEditando = null;
    limpiarFormProducto();
    document.getElementById("aviso_edicion").style.display = "none";
    document.getElementById("form_productos").classList.remove("modo-edicion");
    document.getElementById("btn_agregar_prod").textContent = "Agregar producto";
    document.getElementById("btn_cancelar_edicion").style.display = "none";
}

function eliminarProducto(i) {
    productos.splice(i, 1);
    // Si estábamos editando ese item o uno posterior, cancelar edición
    if (indiceProdEditando !== null && indiceProdEditando >= i) {
        cancelarEdicion();
    }
    actualizarTabla(document.getElementById("moneda").value);
}

function limpiarFormProducto() {
    document.getElementById("producto_desc").value = "";
    document.getElementById("producto_cant").value = "";
    document.getElementById("producto_precio").value = "";
    document.getElementById("producto_iva").value = "10.5";
}

function actualizarTabla(moneda) {
    const tbody = document.querySelector("#tabla_productos tbody");
    tbody.innerHTML = "";
    let total = 0, totalIVA = 0;

    productos.forEach((p, i) => {
        total += p.subTotalBase;
        totalIVA += p.totalIVA;

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${p.desc}</td>
            <td>${p.cant}</td>
            <td>${formatearNumero(p.precio)} ${moneda}</td>
            <td>${formatearNumero(p.subTotalBase)} ${moneda}</td>
            <td>${p.ivaPorc}%</td>
            <td>${formatearNumero(p.totalIVA)} ${moneda}</td>
            <td>
                <button class="btn-editar" onclick="editarProducto(${i})" title="Editar">✏️</button>
                <button onclick="eliminarProducto(${i})" title="Eliminar">🗑</button>
            </td>`;
        tbody.appendChild(tr);
    });

    const totalFinal = total + totalIVA;
    document.getElementById("total").innerText = formatearNumero(total);
    document.getElementById("iva_total").innerText = formatearNumero(totalIVA);
    document.getElementById("total_final").innerText = formatearNumero(totalFinal);
    document.querySelectorAll(".simbolo_moneda").forEach(el => el.innerText = moneda);
}

// ─── Presupuesto ──────────────────────────────────────────────────────────────
function generarPresupuesto() {
    if (productos.length === 0) {
        alert("Agregá al menos un producto.");
        return;
    }

    const empresa = {
        nombre: document.getElementById("empresa_nombre").value,
        cuit: document.getElementById("empresa_cuit").value,
        direccion: document.getElementById("empresa_direccion").value,
        mail: document.getElementById("empresa_mail").value,
        tel: document.getElementById("empresa_tel").value
    };
    const cliente = {
        nombre: document.getElementById("cliente_nombre").value,
        cuit: document.getElementById("cliente_cuit").value,
        direccion: document.getElementById("cliente_direccion").value,
        mail: document.getElementById("cliente_mail").value
    };
    const presupuesto = {
        moneda: document.getElementById("moneda").value,
        fecha: document.getElementById("fecha").value,
        validez: document.getElementById("validez").value,
        pago: document.getElementById("pago").value,
        productos: [...productos],
        totales: {
            neto: document.getElementById("total").innerText,
            iva: document.getElementById("iva_total").innerText,
            final: document.getElementById("total_final").innerText
        }
    };

    guardarClienteServidor(cliente);

    fetch("guardar_presupuesto.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ empresa, cliente, presupuesto })
    })
        .then(res => res.json())
        .then(data => {
            if (data.codigo) presupuesto.codigo = data.codigo;

            ultimoPresupuesto = { empresa, cliente, presupuesto };
            historial.push({ empresa, cliente, presupuesto });
            mostrarHistorial();
            verPresupuesto(historial.length - 1);
        })
        .catch(err => console.error("Error al guardar presupuesto:", err));
}

function verPresupuesto(i) {
    const { empresa, cliente, presupuesto } = historial[i];
    let html = `
        <h2>Presupuesto — ${presupuesto.codigo || ""}</h2>
        <h3>Empresa</h3>
        <p><strong>${empresa.nombre}</strong> (CUIT: ${empresa.cuit})<br>
        ${empresa.direccion}<br>${empresa.mail} — ${empresa.tel}</p>
        <h3>Cliente</h3>
        <p><strong>${cliente.nombre}</strong> (CUIT: ${cliente.cuit})<br>
        ${cliente.direccion}<br>${cliente.mail}</p>
        <p><strong>Fecha:</strong> ${presupuesto.fecha}</p>
        <p><strong>Validez:</strong> ${presupuesto.validez} días</p>
        <p><strong>Forma de pago:</strong> ${presupuesto.pago}</p>
        <h3>Productos</h3>
        <table border="1" cellspacing="0" cellpadding="5">
        <tr><th>Descripción</th><th>Cant</th><th>Precio Base</th><th>Sub-Tot Base</th><th>IVA (%)</th><th>Total IVA</th></tr>`;

    presupuesto.productos.forEach(p => {
        html += `<tr>
            <td>${p.desc}</td><td>${p.cant}</td>
            <td>${p.precio.toFixed(2)} ${presupuesto.moneda}</td>
            <td>${p.subTotalBase.toFixed(2)} ${presupuesto.moneda}</td>
            <td>${p.ivaPorc}%</td>
            <td>${p.totalIVA.toFixed(2)} ${presupuesto.moneda}</td>
        </tr>`;
    });

    html += `</table>
        <div class="totales">
            <p><strong>Total Neto:</strong> ${presupuesto.totales.neto} ${presupuesto.moneda}</p>
            <p><strong>Total IVA:</strong> ${presupuesto.totales.iva} ${presupuesto.moneda}</p>
            <p><strong>Total Final:</strong> ${presupuesto.totales.final} ${presupuesto.moneda}</p>
        </div>`;

    document.getElementById("resultado").innerHTML = html;
    document.getElementById("resultado").scrollIntoView({ behavior: "smooth", block: "start" });
}

// ─── Historial ────────────────────────────────────────────────────────────────
function cargarHistorial() {
    fetch("obtener_historial.php")
        .then(res => res.json())
        .then(data => {
            historial = data;
            mostrarHistorial();
        })
        .catch(err => console.error("Error cargando historial:", err));
}

function mostrarHistorial() {
    const filtro = document.getElementById("filtro_cliente").value.toLowerCase();
    const lista = document.getElementById("lista_historial");
    lista.innerHTML = "";

    // Crear pares {h, i} para conservar el índice real del array tras ordenar
    const indexados = historial
        .map((h, i) => ({ h, i }))
        .filter(({ h }) =>
            h.cliente.nombre.toLowerCase().includes(filtro) ||
            (h.presupuesto.codigo || "").toLowerCase().includes(filtro)
        )
        .sort((a, b) => {
            // Ordenar por fecha descendente; si empatan, por número de código descendente
            const fechaDiff = new Date(b.h.presupuesto.fecha) - new Date(a.h.presupuesto.fecha);
            if (fechaDiff !== 0) return fechaDiff;
            const numA = parseInt((a.h.presupuesto.codigo || "").replace(/\D/g, "")) || 0;
            const numB = parseInt((b.h.presupuesto.codigo || "").replace(/\D/g, "")) || 0;
            return numB - numA;
        });

    if (indexados.length === 0) {
        lista.innerHTML = '<li class="historial-vacio">No hay presupuestos que coincidan.</li>';
        return;
    }

    indexados.forEach(({ h, i }) => {
        const li = document.createElement("li");

        const info = document.createElement("span");
        info.className = "historial-info";
        info.innerHTML = `<span class="historial-codigo">${h.presupuesto.codigo || "—"}</span>`
            + ` <span class="historial-cliente">${h.cliente.nombre}</span>`
            + ` <span class="historial-fecha">${formatearFecha(h.presupuesto.fecha)}</span>`;

        const acciones = document.createElement("span");
        acciones.className = "historial-acciones";

        const verBtn = document.createElement("button");
        verBtn.innerHTML = "👁 Ver";
        verBtn.className = "btn-ver";
        verBtn.onclick = () => verPresupuesto(i);

        const pdfBtn = document.createElement("button");
        pdfBtn.innerHTML = "⬇ PDF";
        pdfBtn.className = "btn-pdf";
        pdfBtn.onclick = () => descargarPDF(i);

        const delBtn = document.createElement("button");
        delBtn.innerHTML = "🗑";
        delBtn.className = "btn-eliminar";
        delBtn.title = "Eliminar presupuesto";
        delBtn.onclick = () => eliminarPresupuesto(i, h.presupuesto.codigo);

        acciones.appendChild(verBtn);
        acciones.appendChild(pdfBtn);
        acciones.appendChild(delBtn);
        li.appendChild(info);
        li.appendChild(acciones);
        lista.appendChild(li);
    });
}

function formatearFecha(fechaStr) {
    if (!fechaStr) return "—";
    const [y, m, d] = fechaStr.split("-");
    return `${d}/${m}/${y}`;
}

function eliminarPresupuesto(i, codigo) {
    if (!confirm(`¿Eliminar el presupuesto ${codigo || "seleccionado"}? Esta acción no se puede deshacer.`)) return;

    fetch("eliminar_presupuesto.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codigo })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status === "ok") {
                historial.splice(i, 1);
                mostrarHistorial();
                // Limpiar el panel de vista si mostraba ese presupuesto
                const resultado = document.getElementById("resultado");
                if (resultado.querySelector("h2")?.textContent.includes(codigo)) {
                    resultado.innerHTML = "";
                }
            } else {
                alert("Error al eliminar: " + (data.mensaje || "desconocido"));
            }
        })
        .catch(err => console.error("Error eliminando presupuesto:", err));
}

// ─── PDF ──────────────────────────────────────────────────────────────────────
function descargarPDF(i = null) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;

    let empresa, cliente, presupuesto;

    if (i === null) {
        if (!ultimoPresupuesto) {
            alert("Primero generá un presupuesto.");
            return;
        }
        ({ empresa, cliente, presupuesto } = ultimoPresupuesto);
    } else {
        ({ empresa, cliente, presupuesto } = historial[i]);
    }

    doc.setFontSize(10);
    doc.text(`N°: ${presupuesto.codigo || "—"}`, pageWidth - 20, 20, { align: "right" });
    doc.setFontSize(16);
    doc.text("Presupuesto", pageWidth / 2, 15, { align: "center" });
    doc.setFontSize(12);
    doc.text(`Empresa: ${empresa.nombre} (CUIT: ${empresa.cuit})`, 14, 30);
    doc.text(`${empresa.direccion}`, 14, 36);
    doc.text(`${empresa.mail} - ${empresa.tel}`, 14, 42);
    doc.text(`Cliente: ${cliente.nombre} (CUIT: ${cliente.cuit})`, 14, 54);
    doc.text(`${cliente.direccion}`, 14, 60);
    doc.text(`${cliente.mail}`, 14, 66);
    doc.text(`Fecha: ${presupuesto.fecha}`, 14, 78);
    doc.text(`Validez: ${presupuesto.validez} días`, 14, 84);
    doc.text(`Forma de pago: ${presupuesto.pago}`, 14, 90);

    doc.autoTable({
        startY: 100,
        head: [["Descripción", "Cant", "Precio Base", "Sub-Tot Base", "IVA (%)", "Total IVA"]],
        body: presupuesto.productos.map(p => [
            p.desc, p.cant,
            formatearNumero(p.precio) + " " + presupuesto.moneda,
            formatearNumero(p.subTotalBase) + " " + presupuesto.moneda,
            p.ivaPorc + "%",
            formatearNumero(p.totalIVA) + " " + presupuesto.moneda
        ]),
        theme: "grid",
        headStyles: { fillColor: [48, 48, 48], textColor: [245, 241, 232] },
        alternateRowStyles: { fillColor: [249, 249, 249] }
    });

    const totales = [
        ["Total Neto:", presupuesto.totales.neto + " " + presupuesto.moneda],
        ["Total IVA:", presupuesto.totales.iva + " " + presupuesto.moneda],
        ["Total Final:", presupuesto.totales.final + " " + presupuesto.moneda]
    ];
    const tableWidth = Math.max(...totales.map(r => doc.getTextWidth(r[0] + " " + r[1]))) + 20;

    doc.autoTable({
        body: totales,
        startY: doc.lastAutoTable.finalY + 10,
        theme: "grid",
        tableWidth: "auto",
        margin: { left: pageWidth - tableWidth - 14 },
        styles: { halign: "right", cellPadding: 3 },
        bodyStyles: { fillColor: [245, 241, 232], textColor: [48, 48, 48] },
        didParseCell: function (data) {
            if (data.row.index === 2) {
                data.cell.styles.fillColor = [190, 161, 103];
                data.cell.styles.textColor = [48, 48, 48];
                data.cell.styles.fontStyle = "bold";
            }
        }
    });

    const codigo = presupuesto.codigo || "SIN-CODIGO";
    const nombreCliente = (cliente.nombre || "Cliente")
        .replace(/[^a-z0-9]/gi, "_")
        .toUpperCase();

    doc.save(`${codigo}_${nombreCliente}.pdf`);
}

// ─── Utilidades ───────────────────────────────────────────────────────────────
function formatearNumero(num) {
    return Number(num).toLocaleString("es-AR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}
